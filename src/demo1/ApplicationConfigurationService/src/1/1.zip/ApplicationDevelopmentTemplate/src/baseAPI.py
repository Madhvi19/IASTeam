def appInit():
    #here we have to start the thread
    #and keep on sending alive singnal to it.
    pass


def appExit():
    #here we have send the termination signal to the runtime maneger.
    pass


def get(label,field):
    return 0

def applyControl(label,field,dict):
    pass